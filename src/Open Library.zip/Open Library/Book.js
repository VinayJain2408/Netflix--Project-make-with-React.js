import React from 'react'

function Book() {
  return (
    <div>Book</div>
  )
}

export default Book